function trajectory_plotter()
    % 创建持久变量来存储轨迹数据
    persistent fig ax positions first_call grid_size
    
    % 初始化参数
    if isempty(first_call)
        first_call = true;
        positions = [];  % 存储所有坐标位置
        grid_size = [10, 10];  % 网格大小 [行数, 列数]
    end
    
    % 创建图形窗口
    if isempty(fig) || ~isvalid(fig)
        fig = figure('Name', '实时轨迹图', 'NumberTitle', 'off');
        ax = axes('Parent', fig);
        
        % 设置网格
        grid on;
        hold on;
        axis equal;
        
        % 设置坐标轴范围
        xlim([0.5, grid_size(2) + 0.5]);
        ylim([0.5, grid_size(1) + 0.5]);
        
        % 设置网格线
        set(ax, 'XTick', 1:grid_size(2), 'YTick', 1:grid_size(1));
        set(ax, 'GridLineStyle', '-', 'GridAlpha', 0.3);
        
        xlabel('X坐标');
        ylabel('Y坐标');
        title('物体移动轨迹实时显示');
    end
    
    % 等待用户输入新坐标（在实际应用中，这里可以替换为传感器数据或其他输入）
    if first_call
        disp('请输入起始坐标 [x, y]:');
        first_call = false;
    else
        disp('请输入下一个坐标 [x, y] (输入空值退出):');
    end
    
    try
        new_pos = input('');
    catch
        return;
    end
    
    % 检查是否退出
    if isempty(new_pos)
        disp('程序结束');
        return;
    end
    
    % 验证输入坐标
    if length(new_pos) ~= 2 || any(new_pos < 0.5) || any(new_pos > grid_size + 0.5)
        disp('错误：请输入有效的坐标，格式为 [x, y]');
        trajectory_plotter();
        return;
    end
    
    % 添加新坐标到轨迹
    positions = [positions; new_pos];
    
    % 清除之前的绘图（保留网格）
    cla(ax);
    grid on;
    
    % 绘制轨迹连线
    if size(positions, 1) > 1
        plot(ax, positions(:, 1), positions(:, 2), 'b-', 'LineWidth', 2);
    end
    
    % 绘制所有位置点
    if ~isempty(positions)
        % 绘制历史点
        scatter(ax, positions(1:end-1, 1), positions(1:end-1, 2), 50, 'g', 'filled');
        
        % 绘制当前点（用不同颜色突出显示）
        scatter(ax, positions(end, 1), positions(end, 2), 80, 'r', 'filled');
        
        % 标记当前点坐标
        text(ax, positions(end, 1) + 0.1, positions(end, 2) + 0.1, ...
            sprintf('(%.1f,%.1f)', positions(end, 1), positions(end, 2)), ...
            'FontSize', 10);
    end
    
    % 刷新图形
    drawnow;
    
    % 递归调用以继续接收新坐标
    trajectory_plotter();
end

