clear;
close all;

%% Base FHS sets
q = 15;
L = 15;
K = 5;
Znh = 2;
basesubsetsnum = Znh + 1;
qs = q/(Znh+1);
for i = 1:basesubsetsnum
    for j =0:qs-1
        F(i,j+1) = (i-1)*qs + j;
    end
end
%% 划分频率子集和种子序列
%构造每个子集对应一个满足彭范界的伪随机调频序列集C，最大汉明相关性 Hs = 1
C = cell(basesubsetsnum,qs);
for i = 1 : basesubsetsnum
    for q = 0:qs-1
        q+(i-1)*q
        C{i,q+1} = circshift(F(i,:),-(q+(i-1)*q));
    end
end
%% SNHZ-FHS生成
for k = 1:K
    for m = 0:L-1
        subsetind = mod(m,basesubsetsnum);
        index = floor(m/basesubsetsnum);
        S(k,m+1) = C{subsetind+1,index+1}(k);
    end
end
C = [11,13,7,10,6,14,4,2,9,8,3,1,15,0,5;
    15,4,8,14,0,10,13,9,2,7,5,12,11,6,3;
    9,14,12,4,3,13,10,15,11,1,6,8,2,5,0;
    14,9,6,15,7,11,2,4,13,0,12,5,10,8,1;
    10,2,0,11,8,15,9,13,4,6,1,3,14,7,12;
    2,10,1,13,5,4,14,11,15,12,0,7,9,3,6;
    13,11,3,2,12,9,15,10,14,5,7,0,4,1,8;
    7,3,11,0,14,6,5,1,12,15,13,2,8,10,4;
    4,15,5,9,1,2,11,14,10,3,8,6,13,12,7;
    3,7,13,1,9,12,8,0,6,4,11,10,5,2,15;
    5,8,4,12,2,1,7,6,0,13,15,14,3,9,11;
    1,0,2,3,4,5,6,7,8,9,10,11,12,13,14;
    0,1,10,7,15,8,12,3,5,14,2,13,6,11,9;
    12,6,9,5,13,3,0,8,7,2,14,15,1,4,10;
    8,5,15,6,10,0,3,12,1,11,4,9,7,14,13;
    6,12,14,8,11,7,1,5,3,10,9,4,0,15,2];
%% Basic Shift Matrix
W = 2;
P = 5;
E0 = zeros(P,W+1);
for w = 0:W
    shiftsqe = (0:P-1)+ w*P;
    E0(:,w+1) = shiftsqe';
end
a = randperm(P, W+1);
a =[1,2,3];
% sample and shift
E = zeros(P,P*(W+1)+1);
SampleList = Sample(E0,a);
for p = 0:P-1
    ShiftArray = CircShift(SampleList,p*a);
    E(:,(1:W+1)+p*(W+1)) = ShiftArray;
end
E(:,end) = E(:,W+2);
%% FHZ shift and interleaved
Uset = cell(15,1);
for r = 1:size(C,1)
   for i =1:P
       Ulist = [];
        for j = 1:(W+1)*P+1
            ShiftArray = CircShift(C(r,:)',E(i,j));
            Ulist = [Ulist,ShiftArray];
        end
        Usubset(i,:) = reshape(Ulist',1,[]);
   end
   Uset{r} = Usubset;
end
croosvalue = Crosslist(Uset{1}(1,:),Uset{1}(2,:),0);
figure(1);
% for i = 1:5
%     for j = i+1:5
        for t =0:239
            croosvalue(t+1) = Crosslist(Uset{1}(1,:),Uset{1}(4,:),t);   
        end
        stem(croosvalue);
        hold on;
%     end
% end
axis([1 240 0 100]);

figure(2);
for t =0:239
    croosvalue(t+1) = Crosslist(Uset{1}(2,:),Uset{14}(3,:),t);   
end
stem(croosvalue);

axis([1 240 0 18]);

figure(3);
for t =1:239
    croosvalue(t) = Crosslist(Uset{1}(1,:),Uset{1}(1,:),t);   
end
stem(croosvalue);

axis([1 240 0 150]);

for m = 0:14
    a(1,m+1) = mod(m,3);
    a(2,m+1) = floor(m/3);
end