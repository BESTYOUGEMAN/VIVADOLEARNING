function croosvalue = Crosslist(list1,list2,delayt)
    list3 = circshift(list2,delayt);
    croosvalue = sum((list1 == list3));
end