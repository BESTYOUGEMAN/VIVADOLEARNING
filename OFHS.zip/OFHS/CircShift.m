function ShiftArray = CircShift(Array,shiftind)
    ShiftArray = zeros(size(Array));
    for i = 1:length(shiftind)
        ShiftArray(:,i) = circshift(Array(:,i),-shiftind(i));
    end
end