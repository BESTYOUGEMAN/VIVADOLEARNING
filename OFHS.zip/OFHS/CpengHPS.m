function C = CpengHPS(q,n,k)
    L = q^n - 1;
    K = q^k;
    Hm = q^(n-k);
    F = q^k;

    %% d 形式函数选择 
    % 有限域的定义 G(2^k) 本原元满足 aref^k + aref +1 = 0 乘法群 F(2^k)* {t= 0:2^k-2}
    % d形式函数表示F(2^n)->F(2^m)的迹函数，满足 f(yx) = y^d*f(x) ,同时需要满足gcd(d,2^m-1)=1
    % d形式函数可以为单迹项函数f(x) = Trq^n/q^m(x^d);
    % Trq^n/q^m(x) = x^(q^(m*(0:(n/m)-1))
    %% 线性无关元素的选择 从F(q^k)中选择在F(q)上的一组基，线性无关元素个数小于等于k 设元素个数为r个

   
    %% 构造分量序列
    % Si(t) i=1:r {t= 0:2^k-2}
    % Si(t) = Trq^m/q(a(i)*f(aref^t))  f(x) = Trq^n/q^m(x^d)

    %% 生成FHS集 生成F(q^n)个偏移量，构造Sv(t) = s(t)+v
end