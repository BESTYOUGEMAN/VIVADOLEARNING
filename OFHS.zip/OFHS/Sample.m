function SampleList = Sample(List,sampestep)
    [rowlen,cloumlen] = size(List);
    SampleList = zeros(size(List));
    for c = 1:cloumlen
        for r =1:rowlen
            SampleList(r,c) = List(mod((r-1)*sampestep(c),rowlen) +1,c);
        end
    end
end