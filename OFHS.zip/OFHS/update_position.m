% 辅助函数：用于外部程序调用的更新函数
function update_position(x, y)
    % 这个函数可以从外部程序调用，用于更新位置
    persistent fig ax positions grid_size
    
    % 初始化
    if isempty(positions)
        positions = [];
        grid_size = [10, 10];
        
        % 创建图形窗口
        fig = figure('Name', '实时轨迹图', 'NumberTitle', 'off');
        ax = axes('Parent', fig);
        
        grid on;
        hold on;
        axis equal;
        xlim([0.5, grid_size(2) + 0.5]);
        ylim([0.5, grid_size(1) + 0.5]);
        set(ax, 'XTick', 1:grid_size(2), 'YTick', 1:grid_size(1));
        xlabel('X坐标');
        ylabel('Y坐标');
        title('物体移动轨迹实时显示');
    end
    
    % 添加新坐标
    positions = [positions; x, y];
    
    % 清除并重绘
    cla(ax);
    grid on;
    
    % 绘制轨迹
    if size(positions, 1) > 1
        plot(ax, positions(:, 1), positions(:, 2), 'b-', 'LineWidth', 2);
    end
    
    % 绘制点
    if ~isempty(positions)
        scatter(ax, positions(1:end-1, 1), positions(1:end-1, 2), 50, 'g', 'filled');
        scatter(ax, positions(end, 1), positions(end, 2), 80, 'r', 'filled');
        
        text(ax, positions(end, 1) + 0.1, positions(end, 2) + 0.1, ...
            sprintf('(%.1f,%.1f)', x, y), 'FontSize', 10);
    end
    
    drawnow;
end