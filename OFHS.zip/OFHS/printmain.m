% 在循环中调用更新函数
for i = 1:10
    x = i;
    y = sin(i) + 3;
    update_position(x, y);
    pause(1);  % 暂停1秒模拟实时更新
end